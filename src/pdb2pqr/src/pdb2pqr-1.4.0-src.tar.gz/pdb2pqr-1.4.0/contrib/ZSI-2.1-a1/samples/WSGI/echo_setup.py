#!/bin/sh
wsdl2py -b SimpleEcho.wsdl
